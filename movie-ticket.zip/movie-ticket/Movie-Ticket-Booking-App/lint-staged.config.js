module.exports = {
  '*.{ts,tsx,js,json}': () => ['pnpm validate'],
}
