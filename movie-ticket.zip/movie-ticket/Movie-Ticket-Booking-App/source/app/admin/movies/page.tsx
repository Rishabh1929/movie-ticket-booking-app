import { ListMovies } from '@/components/templates/ListMovies'

export default function Page() {
  return (
    <main>
      <ListMovies />
    </main>
  )
}
