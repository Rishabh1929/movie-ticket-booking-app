import { CreateMovie } from '@/components/templates/CreateMovie'

export default function Page() {
  return (
    <main>
      <CreateMovie />
    </main>
  )
}
