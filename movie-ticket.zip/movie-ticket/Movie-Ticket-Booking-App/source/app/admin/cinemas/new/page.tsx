import { CreateCinema } from '@/components/templates/CreateCinema'

export default function Page() {
  return (
    <main>
      <CreateCinema />
    </main>
  )
}
