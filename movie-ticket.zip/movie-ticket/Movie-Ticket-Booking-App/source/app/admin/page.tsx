export default function Page() {
  return <main>Hello this is admin.</main>
}
