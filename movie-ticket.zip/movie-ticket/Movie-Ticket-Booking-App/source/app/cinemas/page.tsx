import { SearchCinemas } from '@/components/templates/SearchCinemas'

export default function Page() {
  return (
    <main>
      <SearchCinemas />
    </main>
  )
}
