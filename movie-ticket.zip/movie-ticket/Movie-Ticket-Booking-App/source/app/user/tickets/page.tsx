import { Tickets } from '@/components/templates/Tickets'

export default function Page() {
  return (
    <main>
      <Tickets />
    </main>
  )
}
