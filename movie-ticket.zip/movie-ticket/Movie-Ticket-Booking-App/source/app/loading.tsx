import { Loader } from 'lucide-react'

export default function Page() {
  return (
    <div className="flex justify-center py-32">
      <Loader className="animate-spin" />
    </div>
  )
}
