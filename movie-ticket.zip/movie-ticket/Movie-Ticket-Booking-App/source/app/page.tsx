import Home from '@/components/templates/Home'

export default function Page() {
  return (
    <main>
      <Home />
    </main>
  )
}
