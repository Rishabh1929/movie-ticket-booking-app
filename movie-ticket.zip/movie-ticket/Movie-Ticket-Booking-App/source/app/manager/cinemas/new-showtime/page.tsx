import { CreateShowtime } from '@/components/templates/CreateShowtime'

export default function Page() {
  return (
    <main>
      <CreateShowtime />
    </main>
  )
}
