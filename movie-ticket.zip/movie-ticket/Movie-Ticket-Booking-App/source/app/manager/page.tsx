export default function Page() {
  return <main>Hello this is manager.</main>
}
